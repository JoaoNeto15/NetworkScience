import pandas as pd
import numpy as np
import csv

def mudar_rota1():
    df["Rota"]=1

def mudar_rota0():
    df["Rota"]=0

df = pd.read_csv("routes.csv")
print(df)

#df["Rota"]=5

df1 = pd.read_csv("Test.csv")
for origem, destino in zip(df["Origem"],df["Destino"]): #ficheiro routes
    for o, d in zip(df1["orgiem"],df1["destino"]): #ficheiro rangel
    #print("O",origem, "D",destino)
        if origem == o and destino == d:
            mudar_rota1()
            #acrescentar nessa linha um 1 na coluna rota
            #df['Rota'] = df['Rota'].replace({'3': '1'})
            print(origem , "  ", destino)
            print("UAU")
        #df['Rota'] = df['Rota'].replace({'3': '0'})
        #mudar_rota0()

print(df)
